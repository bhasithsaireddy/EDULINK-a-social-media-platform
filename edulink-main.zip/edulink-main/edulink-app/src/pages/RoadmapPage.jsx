import React from 'react';
import RoadmapCreator from '../components/RoadmapCreator';

export default function RoadmapPage() {
    return <RoadmapCreator />;
}
